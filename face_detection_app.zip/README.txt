Face Detection App (OpenCV)

Features:
- Webcam face detection
- Haar Cascade face detection
- Rectangle overlay

Install:
pip install opencv-python

Run webcam:
python face_detection_webcam.py

Run image mode:
python face_detection_image.py
