import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# Load dataset
data = pd.read_csv("spam.csv")

X = data["message"]
y = data["label"]

# Build model
model = Pipeline([
    ("tfidf", TfidfVectorizer()),
    ("classifier", MultinomialNB())
])

# Train
model.fit(X, y)

# Predict
msg = input("Enter an email/message: ")
result = model.predict([msg])

print("\nPrediction:", result[0].upper())
