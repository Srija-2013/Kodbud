Spam Email Classifier

Requirements:
pip install pandas scikit-learn

Run:
python spam_classifier.py

Dataset:
spam.csv
