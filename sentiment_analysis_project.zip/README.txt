Sentiment Analysis on Reviews/Tweets

Tools:
- NLTK
- scikit-learn

Features:
- Text cleaning
- TF-IDF feature extraction
- Naive Bayes classification
- Positive/Negative prediction

Install:
pip install pandas nltk scikit-learn

Run:
python sentiment_analysis.py
